using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class admin_AssignRoles : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            LoadUserNames();
            LoadRoles();
        }

    }

    private void LoadRoles()
    {
        string [] roles = Roles.GetAllRoles();
        foreach (string role in roles)
        {
            DropDownList2.Items.Add(role);
        }
    }

    private void LoadUserNames()
    {
       
        foreach (MembershipUser user in Membership.GetAllUsers())
        {
            DropDownList1.Items.Add(user.UserName);
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Roles.IsUserInRole(DropDownList1.SelectedItem.Text, DropDownList2.SelectedItem.Text))
        {
            Label1.Text = "User already assigned to this Role";
        }
        else
        {
            Roles.AddUserToRole(DropDownList1.SelectedItem.Text, DropDownList2.SelectedItem.Text);
            Label1.Text = "User assigned to this Role successfully";
        }
    }
}
