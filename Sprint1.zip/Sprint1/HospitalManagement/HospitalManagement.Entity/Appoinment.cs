﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement.Entity
{
    [Serializable]
    public class Appointment
    {
        public string AppointmentId { get; set; }
        public string DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string DoctorDepartment { get; set; }
        public string RoomNo { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public float AmmountPerDay { get; set; }
        public DateTime TreatmentDate { get; set; }
        
    }
}
