﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement.Entity
{
    [Serializable]
    public class LabDetails
    {
        public string LabId { get; set; }
        public string TestType { get; set; }
        public string LabNo { get; set; }
        public string TestDate { get; set; }
        public string PatientType { get; set; }
        public string Result { get; set; }
    }

    
}
