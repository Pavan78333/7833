﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HospitalManagement.Exception;
using HospitalManagement.Entity;

namespace HospitalManagement.DataAccess
{
    public static class DatabaseOperation
    {
        public static List<Patient> patients = new List<Patient>();
        public static void PatientListSerializer(Patient patient)
        {
            patients = PatientListDeSerializer();
            patients.Add(patient);
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Patient.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, patients);
            stream.Close();

        }
        public static List<Patient> PatientListDeSerializer()
        {

            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Patient.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<Patient> patientList = (List<Patient>)formatter.Deserialize(stream);
            stream.Close();
            return patientList;
        }
        //public static List<Doctor> doctors = new List<Doctor>();
        //public static void DoctorListSerializer(Doctor doctor)
        //{
        //    doctors = DoctorListDeSerializer();
        //    doctors.Add(doctor);
        //    string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Doctor.txt";
        //    BinaryFormatter formatter = new BinaryFormatter();
        //    Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
        //    formatter.Serialize(stream, doctors);
        //    stream.Close();

        //}
        //public static List<Doctor> DoctorListDeSerializer()
        //{
        //    string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Doctor.txt";
        //    BinaryFormatter formatter = new BinaryFormatter();
        //    Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
        //    List<Doctor> doctorList = (List<Doctor>)formatter.Deserialize(stream);
        //    stream.Close();
        //    return doctorList;
        //}
        public static List<LabDetails> labDetails = new List<LabDetails>();
        public static void LabListSerializer(LabDetails lab)
        {
          
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\LabDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            labDetails = LabListDeSerializer();
            labDetails.Add(lab);
            formatter.Serialize(stream, labDetails);

            stream.Close();

        }
        public static List<LabDetails> LabListDeSerializer()
        {
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\LabDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<LabDetails> labsList = (List<LabDetails>)formatter.Deserialize(stream);
            stream.Close();
            return labsList;
        }
        public static List<Appointment> appointmentDetails = new List<Appointment>();
        public static void AppointmentListSerializer(Appointment appointment)
        {
            appointmentDetails = AppointmentListDeSerializer();
            appointmentDetails.Add(appointment);
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Appointment.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, appointmentDetails);
            stream.Close();

        }
        public static List<Appointment> AppointmentListDeSerializer()
        {
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\Appointment.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<Appointment> appointmentLists = (List<Appointment>)formatter.Deserialize(stream);
            stream.Close();
            return appointmentLists;
        }
        public static List<BillDetails> billDetails = new List<BillDetails>();


        public static void BillDetailsListSerializer(BillDetails billData)
        {
            billDetails = BillDetailsListDeSerializer();
            billDetails.Add(billData);
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\BillDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Create, FileAccess.Write);
            formatter.Serialize(stream, billDetails);
            stream.Close();

        }
        public static List<BillDetails> BillDetailsListDeSerializer()
        {
            string path = @"C:\Users\GAPAVAN\Desktop\Sprint1\BillDetails.txt";
            BinaryFormatter formatter = new BinaryFormatter();
            Stream stream = File.Open(path, FileMode.Open, FileAccess.Read);
            List<BillDetails> billDetailLists = (List<BillDetails>)formatter.Deserialize(stream);
            stream.Close();
            return billDetailLists;
        }
    }
}
