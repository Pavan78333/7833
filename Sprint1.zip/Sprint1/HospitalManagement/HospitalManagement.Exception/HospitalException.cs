﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagement.Exception
{
    public class HospitalException : ApplicationException
    {
        public HospitalException(string str) : base(str)
        {

        }
    }
}
