﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalManagement.Exception;
using HospitalManagement.Entity;
using HospitalManagement.BussinessLogic;


namespace HospitalManagement.Presentation
{
    class Program
    {

        public static BussinessOperations business = new BussinessOperations();
        public static List<Patient> patientList = new List<Patient>();
        static void Main(string[] args)
        {

            try
            {
                int choice;
                while (true)
                {

                    Console.WriteLine("1. Adding Patient Information");
                    Console.WriteLine("2. Modify Patient Information");
                    Console.WriteLine("3. Add patient Treatment Information");
                    Console.WriteLine("4. View Patientn && Patient Appointment History");
                    Console.WriteLine("5. Search Patient Information");
                    Console.WriteLine("6. Generate Lab Reports");
                    Console.WriteLine("7. Generate Medical Bills");
                    Console.WriteLine("8. Exit");
                    Console.WriteLine("Enter Your Choice:");
                    choice = Convert.ToInt32(Console.ReadLine());
                    //menu driven in which you do the operation
                    switch (choice)
                    {
                        case 1:
                            if (business.AddPatient(AddPatientDetails()))
                            {
                                Console.WriteLine("patient information is added Successfully");
                            }
                            else
                            {
                                Console.WriteLine("Error in adding patient info!");
                            }
                            break;
                        case 2:
                            Console.WriteLine("1.Replace by Id");
                            Console.WriteLine("2.Replace by Name");
                            Console.WriteLine("3.Replace by Disease");
                            Console.WriteLine("Enter your Choice to Replace");

                            choice = Convert.ToInt32(Console.ReadLine());
                            switch (choice)
                            {
                                case 1:
                                    if (business.AddPatient(ReplacePatientId()))
                                    {
                                        Console.WriteLine("patient information is added Successfully");
                                    }
                                    else
                                    {
                                        Console.WriteLine("Error in adding patient info!");
                                    }

                                    break;
                                case 2:

                                    //ReplacePatientName();

                                    break;
                                case 3:
                                    // ReplacePatientDisease();
                                    break;
                                default:
                                    Console.WriteLine("Invalid Choice");
                                    break;
                            }



                            break;
                        case 3:
                            if (business.AddAppointments(AddTreatmentInfo()))
                            {
                                Console.WriteLine("Patient treatment information is added Successfully");
                            }
                            else
                            {
                                Console.WriteLine("Error in adding patient treatment info!");
                            }
                            break;

                        case 4:
                            DisplayPatients(business.GetPatientsDetails());
                            DisplayTreatmentInfo(business.GetAppointmentDetails());
                         //   DisplayLadDetailsInfo(business.GetLabDetails());
                            break;
                        case 5:
                            Console.WriteLine("1.Search by Id");
                            Console.WriteLine("2.Search by Name");
                            Console.WriteLine("3.Search by Gender");
                            Console.WriteLine("Enter your Choice to Search");

                            choice = Convert.ToInt32(Console.ReadLine());
                            switch (choice)
                            {
                                case 1:
                                    SearchPatientIdList();
                                    break;
                                case 2:

                                    SearchPatientName();

                                    break;
                                case 3:
                                    SearchPatientGenderList();
                                    break;
                                default:
                                    Console.WriteLine("Invalid Choice");
                                    break;
                            }
                            break;
                        case 6:
                            if (business.AddLabs(AddLabDetails()))
                            {
                                Console.WriteLine("patient information is added Successfully");
                            }
                            else
                            {
                                Console.WriteLine("Error in adding patient info!");
                            }
                            break;

                        case 7:
                            if (business.AddBillDetails(AddBillingDetails()))
                            {
                                Console.WriteLine("BillingDetails is added Successfully");
                            }
                            else
                            {
                                Console.WriteLine("Error in adding  BillingDetails");
                            }
                            break;
                        case 8:
                            Environment.Exit(0);
                            break;
                        default:
                            Console.WriteLine("Invalid Choice");
                            break;
                    }
                }
            }
            catch (HospitalException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
        }
        public static Patient AddPatientDetails()
        {
            Patient patientList = new Patient();
            try
            {

                Console.WriteLine("Enter The patient ID");
                patientList.PatientId = Console.ReadLine();

                Console.WriteLine("Enter The  patient Name");
                patientList.PatientName = Console.ReadLine();
                Console.WriteLine("Enter The patient Age");
                patientList.PatientAge = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter The patient Weight");
                patientList.PatientWeight = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter The patient Gender");
                patientList.PatientGender = Console.ReadLine();
                Console.WriteLine("Enter The patient PhoneNumber");
                patientList.PatientPhoneNo = Console.ReadLine();
                Console.WriteLine("Enter The patient Disease");
                patientList.PatientDisease = Console.ReadLine();
                Console.WriteLine("Enter The patient Address");
                patientList.PatientAddress = Console.ReadLine();

            }
            catch (HospitalException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return patientList;

        }

        public static void DisplayPatients(List<Patient> patients)
        {
            Console.WriteLine("**********************************************************************************************************");
            Console.WriteLine("PatientId PatientName PatientAge  PatientWeight PatientGender PatientAddress PatientPhoneNo PatientDisease");
            Console.WriteLine("**********************************************************************************************************");
            foreach (Patient patient in patients)
            {
                Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");

            }
        }
        public static void SearchPatientIdList()
        {
            Console.WriteLine("Enter Patient ID to serach ");
            string patientId = Console.ReadLine();
            Patient patient = business.SearchPatientById(patientId);
            if (patient != null)
            {
                Console.WriteLine("**********************************************************************************************************");
                Console.WriteLine("PatientId PatientName PatientAge  PatientWeight PatientGender PatientAddress PatientPhoneNo PatientDisease");
                Console.WriteLine("**********************************************************************************************************");

                {
                    Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");

                }
            }
            else
            {
                Console.WriteLine($"Patient with the specified id:{patientId} doesnotpresent!");
            }
        }
        public static void SearchPatientName()

        {
            Console.WriteLine("Enter Patient Name to serach ");
            string patientName = Console.ReadLine();
            List<Patient> patients = business.SearchPatientByName(patientName);
            foreach (Patient patient in patients)
            {
                Console.WriteLine("**********************************************************************************************************");
                Console.WriteLine("PatientId PatientName PatientAge  PatientWeight PatientGender PatientAddress PatientPhoneNo PatientDisease");
                Console.WriteLine("**********************************************************************************************************");
                Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");

            }
        }
        public static void SearchPatientGenderList()
        {
            Console.WriteLine("Enter PatientGender to serach ");
            string patientGender = Console.ReadLine();
            List<Patient> patients = business.SearchPatientByGender(patientGender);
            Console.WriteLine("**********************************************************************************************************");
            Console.WriteLine("PatientId PatientName PatientAge  PatientWeight PatientGender PatientAddress PatientPhoneNo PatientDisease");
            Console.WriteLine("**********************************************************************************************************");
            foreach (Patient patient in patients)
            {
                Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");

            }

        }

        public static Patient ReplacePatientId()
        {
            Console.WriteLine("Enter Patient ID to serach ");
            string patientId = Console.ReadLine();
            Patient patient = business.SearchPatientById(patientId);
            Console.WriteLine("Enter Id to be replaced");
            string id = Console.ReadLine();

            patient.PatientId = patientId.Replace(patient.PatientId, id);

            if (patient.PatientId == id)
            {
                Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");
            }

            return patient;
        }

        public static Appointment AddTreatmentInfo()
        {
            Appointment TreatmentList = new Appointment();
            try
            {

                Console.WriteLine("Enter The Appointment ID");
                TreatmentList.AppointmentId = Console.ReadLine();

                Console.WriteLine("Enter The  Doctor ID");
                TreatmentList.DoctorId = Console.ReadLine();

                Console.WriteLine("Enter The Doctor Name");
                TreatmentList.DoctorName = Console.ReadLine();

                Console.WriteLine("Enter The Doctor Department");
                TreatmentList.DoctorDepartment = Console.ReadLine();

                Console.WriteLine("Enter The Room No");
                TreatmentList.RoomNo = Console.ReadLine();

                Console.WriteLine("Enter The patient Admission Date");
                TreatmentList.AdmissionDate = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter The Amount PerDay");
                TreatmentList.AmmountPerDay = Convert.ToSingle(Console.ReadLine());

                Console.WriteLine("Enter The Patient Discharge Date ");
                TreatmentList.DischargeDate = Convert.ToDateTime(Console.ReadLine());

                Console.WriteLine("Enter The Patient Treatment Date");
                TreatmentList.TreatmentDate = Convert.ToDateTime(Console.ReadLine());


            }
            catch (HospitalException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return TreatmentList;

        }


        public static void DisplayTreatmentInfo(List<Appointment> appointments)
        {
            Console.WriteLine("Enter Patient Id");
            string patientId = Console.ReadLine();
            Patient patient = business.SearchPatientById(patientId);
            Console.WriteLine("**********************************************************************************************************");
            Console.WriteLine("AppointmentId    PatientId   DoctorId    DoctorName      DoctorDepartment  RoomNo AdmissionDate DischargeDate AmmountPerDay TreatmentDate    ");
            Console.WriteLine("**********************************************************************************************************");
            foreach (Appointment appointment in appointments)
            {
                Console.WriteLine($"{appointment.AppointmentId}     {patient.PatientId}     {appointment.DoctorId}           {appointment.DoctorName}             { appointment.DoctorDepartment}      {appointment.RoomNo}        {appointment.AdmissionDate}            {appointment.DischargeDate}        { appointment.AmmountPerDay}            { appointment.TreatmentDate} ");

            }
        }


        public static LabDetails AddLabDetails()
        {
            LabDetails labDetails = new LabDetails();
            try
            {

                Console.WriteLine("Enter The Lab ID");
                labDetails.LabId = Console.ReadLine();

                Console.WriteLine("Enter The  Lab Number");
                labDetails.LabNo = Console.ReadLine();
                Console.WriteLine("Enter The Doctor Name");
                labDetails.PatientType = Console.ReadLine();
                Console.WriteLine("Enter The Type of Test");
                labDetails.TestType = Console.ReadLine();
                Console.WriteLine("Enter The Date of Test");
                labDetails.TestDate = Console.ReadLine();
                Console.WriteLine("Enter The Result");
                labDetails.Result = Console.ReadLine();

            }
            catch (HospitalException Exception)
            {
                Console.WriteLine(Exception.Message);
            }
            catch (System.Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            return labDetails;
        }

        public static void DisplayLadDetailsInfo(List<LabDetails> labDetails)
        {
            string patientId = Console.ReadLine();
            Patient patient = business.SearchPatientById(patientId);
            string DoctorId = Console.ReadLine();
            Appointment appointment= business.SearchDoctorById(DoctorId);
            Console.WriteLine("**********************************************************************************************************");
            Console.WriteLine("AppointmentId    PatientId   DoctorId    DoctorName      DoctorDepartment  RoomNo AdmissionDate DischargeDate AmmountPerDay TreatmentDate    ");
            Console.WriteLine("**********************************************************************************************************");
            
            foreach (LabDetails labdetails in labDetails)
            {
                Console.WriteLine($"{labdetails.LabId}     {labdetails.LabNo}     {appointment.DoctorId}   {labdetails.PatientType}           {labdetails.TestType}             { labdetails.TestDate}      {labdetails.Result}");

            }
        }


        public static BillDetails AddBillingDetails()
        {
                BillDetails billDetails= new BillDetails();
                try
                {

                    Console.WriteLine("Enter The Bill No:");
                    billDetails.BillNo= Console.ReadLine();

                    Console.WriteLine("Enter The  Lab Fees");
                    billDetails.LabFees =Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter The  Doctor Fees");
                    billDetails.DoctorFees = Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter The Medical Fees");
                    billDetails.MedicineFees =Convert.ToDouble( Console.ReadLine());    
                    Console.WriteLine("Enter The Operation Charges");
                    billDetails.OperationCharges =Convert.ToDouble(Console.ReadLine());
                    Console.WriteLine("Enter The Total Days");
                    billDetails.TotalDays = Convert.ToDouble(Console.ReadLine());

                //string DoctorId = Console.ReadLine();

                //Appointment appointments = business.SearchDoctorById(DoctorId);
                //Appointment appointment = appointments;
                //billDetails.RoomCharge = (billDetails.TotalDays) * (appointment.AmmountPerDay);
                //Console.WriteLine(billDetails.RoomCharge);
                //billDetails.TotalAmmount = (billDetails.LabFees) + (billDetails.MedicineFees) + (billDetails.OperationCharges);
                //Console.WriteLine(billDetails.TotalAmmount);


            }
                catch (HospitalException Exception)
                {
                    Console.WriteLine(Exception.Message);
                }
                catch (System.Exception exception)
                {
                    Console.WriteLine(exception.Message);
                }
                return billDetails;
        }
        public static void GenerateBillDetails()
        { 
           Console.WriteLine("Enter Bill No to serach ");
            string BillNo = Console.ReadLine();
            BillDetails billValue = business.SearchBillDetailsById(BillNo);
            Console.WriteLine("Enter Patient Id");
            string patientId = Console.ReadLine();
            Patient patient = business.SearchPatientById(patientId);
            Console.WriteLine("Enter Doctor Id");
            string DoctorId = Console.ReadLine();

            Appointment appointment = business.SearchDoctorById(DoctorId);
          
            billValue.RoomCharge = (billValue.TotalDays) * (appointment.AmmountPerDay);
           
            billValue.TotalAmmount = (billValue.LabFees) + (billValue.MedicineFees) + (billValue.OperationCharges);
         
            if (billValue != null)
            {

                Console.WriteLine("**********************************************************************************************************");
                Console.WriteLine("PatientId PatientName PatientAge  PatientWeight PatientGender PatientAddress PatientPhoneNo PatientDisease");
                Console.WriteLine("**********************************************************************************************************");

                {
                    Console.WriteLine($"{patient.PatientId}      {patient.PatientName}           {patient.PatientAge}             { patient.PatientWeight}      {patient.PatientGender}        {patient.PatientAddress}            {patient.PatientPhoneNo}        { patient.PatientDisease} ");
                    Console.WriteLine($"RoomCharge {billValue.RoomCharge}");
                    Console.WriteLine($" Total Ammount{billValue.TotalAmmount}");
                }
            }
            else
            {
                Console.WriteLine($"Patient with the specified id:{patientId} doesnotpresent!");
            }
        }
    }
}
    


